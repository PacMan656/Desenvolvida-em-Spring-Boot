# LABs

## 084_RealizandoDeployNuvemConjuntoAPIsdesenvolvidaSpringBoot

Realizando Deploy na Nuvem de um conjunto de API’s desenvolvida em Spring Boot

DESCRIÇÃO
Neste projeto você terá o desafio de desenvolver um conjunto de API’s utilizando Spring Boot para controlar um estacionamento de veículos. Serão controlados a entrada, saída e valor a ser cobrado do cliente. Iremos aplicar todas as boas práticas de desenvolvimento de API’s incluindo segurança com Spring Security e acesso a banco de dados PostgreSQL. Serão realizados testes e relatórios de cobertura de testes. Após finalizarmos a aplicação e termos enviado para o Github, vamos fazer o deploy na cloud do Heroku a fim de disponibilizar nossa API para a Internet.

Spring Boot - Full-Stack -  Básico
ESPECIALISTA
#### Sandro Giacomozzi
Software engineer, TOTVS

https://web.dio.me/lab/realizando-deploy-na-nuvem-de-um-conjunto-de-apis-desenvolvida-em-spring-boot/learning/064f166c-436f-4194-bb8d-00b2eab00503
